package com.bt.ghraphdb.tinkerpop.entity;

public class Customer {
	private Integer id;

	public Customer(Integer id) {
		super();
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
}
